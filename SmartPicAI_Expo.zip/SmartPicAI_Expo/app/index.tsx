import React, { useState } from "react";
import { View, Text, StyleSheet, Pressable, ScrollView, Image } from "react-native";
import * as ImagePicker from "expo-image-picker";

type Photo = { uri: string };

export default function Home() {
  const [photos, setPhotos] = useState<Photo[]>([]);

  async function pickPhotos() {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) return;

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["images"],
      allowsMultipleSelection: true,
      quality: 1
    });

    if (!result.canceled) {
      setPhotos(result.assets.map(a => ({ uri: a.uri })));
    }
  }

  const categories = [
    ["👤", "People"],
    ["📍", "Places"],
    ["🏷️", "Objects"],
    ["⭐", "Best Photos"],
    ["🔄", "Similar Photos"],
    ["🔎", "AI Search"]
  ];

  return (
    <ScrollView style={styles.page} contentContainerStyle={styles.content}>
      <Text style={styles.title}>SmartPic AI ✨</Text>
      <Text style={styles.subtitle}>Organize your photos intelligently</Text>

      <Pressable style={styles.button} onPress={pickPhotos}>
        <Text style={styles.buttonText}>📸 Choose Photos</Text>
      </Pressable>

      <View style={styles.grid}>
        {categories.map(([icon, name]) => (
          <View style={styles.card} key={name}>
            <Text style={styles.icon}>{icon}</Text>
            <Text style={styles.cardText}>{name}</Text>
          </View>
        ))}
      </View>

      {photos.length > 0 && (
        <>
          <Text style={styles.section}>Selected Photos ({photos.length})</Text>
          <View style={styles.photos}>
            {photos.map((p, i) => (
              <Image key={i} source={{ uri: p.uri }} style={styles.photo} />
            ))}
          </View>
        </>
      )}

      <View style={styles.info}>
        <Text style={styles.infoTitle}>🤖 AI coming next</Text>
        <Text style={styles.infoText}>
          Automatic labels, face grouping, places, best-photo scoring and natural-language photo search.
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: "#F7F5FA" },
  content: { padding: 22, paddingTop: 65, paddingBottom: 40 },
  title: { fontSize: 31, fontWeight: "800", color: "#241B35" },
  subtitle: { fontSize: 16, color: "#6F6878", marginTop: 6, marginBottom: 24 },
  button: { backgroundColor: "#6750A4", padding: 17, borderRadius: 16, alignItems: "center" },
  buttonText: { color: "white", fontSize: 17, fontWeight: "700" },
  grid: { flexDirection: "row", flexWrap: "wrap", gap: 12, marginTop: 22 },
  card: { width: "47%", backgroundColor: "white", borderRadius: 18, padding: 20, minHeight: 115, justifyContent: "center" },
  icon: { fontSize: 30 },
  cardText: { marginTop: 9, fontSize: 15, fontWeight: "700", color: "#302A38" },
  section: { fontSize: 20, fontWeight: "800", marginTop: 28, marginBottom: 12, color: "#241B35" },
  photos: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  photo: { width: 105, height: 105, borderRadius: 12 },
  info: { backgroundColor: "#EDE7F6", borderRadius: 18, padding: 18, marginTop: 26 },
  infoTitle: { fontSize: 17, fontWeight: "800", color: "#3D3152" },
  infoText: { marginTop: 7, lineHeight: 21, color: "#554C61" }
});
