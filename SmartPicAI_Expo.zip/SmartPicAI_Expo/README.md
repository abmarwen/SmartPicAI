# SmartPic AI — Expo

Expo/React Native starter prepared for cloud APK builds.

## Online APK
1. Create an Expo account.
2. Install/use EAS CLI in an online development environment (for example GitHub Codespaces).
3. Run:
   npx eas-cli login
   npx eas-cli build:configure
   npx eas-cli build --platform android --profile preview
4. EAS will provide a link to the generated APK.

This starter currently includes photo selection and the SmartPic UI. The actual AI classification/face grouping/search is the next implementation phase.
